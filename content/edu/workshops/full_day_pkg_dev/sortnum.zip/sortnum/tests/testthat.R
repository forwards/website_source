library(testthat)
library(sortnum)

test_check("sortnum")
